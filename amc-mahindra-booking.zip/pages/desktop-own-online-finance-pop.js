import MobileNumberPopup from "../components/mobile-number-popup";

const DesktopOwnOnlineFinancePop = () => {
  return (
    <div className="relative w-full h-[768px] overflow-hidden bg-[url(/desktopown-onlinefinancepopup@3x.png)] bg-cover bg-no-repeat bg-[top]">
      <MobileNumberPopup />
    </div>
  );
};

export default DesktopOwnOnlineFinancePop;
